#include <FreeRTOS.h>
#include <task.h>

int i, j;

void vLight0On(void *pvParameters){
	//DDRA = 0b11111111;
	//portTickType xLastWakeTime = xTaskGetTickCount();
	for(;;){
		i++;
		taskYIELD();
	//	if( PORTA & (0<<0)) PORTA |= (1<<0);
	//	else PORTA &= ~(1<<0);
		//vTaskDelayUntil(&xLastWakeTime, 10);
			
	}
}
void vLight1On(void *pvParameters){
	//DDRA = 0b11111111;
	//portTickType xLastWakeTime = xTaskGetTickCount();
	for(;;){
		j++;
		taskYIELD();
	//		PORTA |= (1<<1);
			//for(long long i=0; i < 100000000; i++);
	//		PORTA &= (0<<1);
			//for(long long i=0; i < 100000000; i++);
	}
}



int main(void)
{
	

	xTaskCreate(vLight0On, "i Light 0 on", 10, NULL, 1, NULL);
	xTaskCreate(vLight1On, "j Light 1 on", 10, NULL, 2, NULL);
	vTaskStartScheduler();
	for(;;);
	return 0;
}
